class Constraint:

    def update_constraint(self, ui_element=None):
        """
        Each constraint subclass is called through this method
        :param ui_element: The UI element to modify
        :return:
        """
