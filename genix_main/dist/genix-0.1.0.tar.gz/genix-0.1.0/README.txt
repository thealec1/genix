 _______  _______  _       _________         
(  ____ \(  ____ \( (    /|\__   __/|\     /|
| (    \/| (    \/|  \  ( |   ) (   ( \   / )
| |      | (__    |   \ | |   | |    \ (_) / 
| | ____ |  __)   | (\ \) |   | |     ) _ (  
| | \_  )| (      | | \   |   | |    / ( ) \ 
| (___) || (____/\| )  \  |___) (___( /   \ )
(_______)(_______/|/    )_)\_______/|/     \|


Genix is a new pygame GUI library.  It aims to be very readable, and straightforward when creating UI elements like inventories or main menus for games.


To install:

pip install genix